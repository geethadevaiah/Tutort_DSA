package WarmupPracticeSet_I;

public class _9_FIndSumOfN {

	// sum of n = n * (n + 1) / 2
	public static int findSum(int n) {
		return n * (n + 1) / 2;
	}
}
